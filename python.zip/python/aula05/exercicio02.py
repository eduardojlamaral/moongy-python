import exercicio01


t = exercicio01.Turma()


t.addPessoa( exercicio01.Pessoa("Alexandra", 25) )

t.listaPessoas()