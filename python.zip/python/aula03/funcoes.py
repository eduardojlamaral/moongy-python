
def fn_calcula_potencia(base, potencia=10 ):
    return base ** potencia


print (fn_calcula_potencia(base=2))