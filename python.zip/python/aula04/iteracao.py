
lista = [1,3,5,6,7,9]
ilista = iter(lista)

print(next(ilista))
print(next(ilista))
print(next(ilista))

class Numeros:

    # ... MapReduce

    def __iter__(self):
        self.x = 1
        return self
    
    def __next__(self):
        if self.x <= 50:
            y = self.x
            self.x +=10
            return y
        else:
            raise StopIteration
    
num1 = Numeros()
inum1 = iter(num1)

for y in inum1:
    print(y)






    




#n = Numeros(a=10)
#n.teste()

