from mongoengine import *
import datetime
from mongoengine import connect


connect(host="mongodb+srv://dbformacao:akGq6k9yogoggelF@cluster0.nnqg9f9.mongodb.net/?retryWrites=true&w=majority", db="orm_ea01", alias="orm_ea01")
#connect(host="mongodb+srv://dbformacao:akGq6k9yogoggelF@cluster0.nnqg9f9.mongodb.net/?retryWrites=true&w=majority",db="orm_ea02", alias="orm_ea02")

class Produto(Document):
    descricao = StringField(max_length=100, required=True)
    meta = { 'db_alias': "orm_ea01"}

class Linha(EmbeddedDocument):
    produto = ReferenceField(Produto)
    quantidade = DecimalField(required=True,min_value=0, precision=4)
    preco = DecimalField(required=True,min_value=0, precision=4)
    iva = DecimalField(required=True,min_value=0, precision=4)
    meta = { 'db_alias': "orm_ea01"}

class Factura(Document):
    descricao = StringField(max_length=100, required=True)
    valor = DecimalField(required=True,min_value=0, precision=4)
    data_factura = DateTimeField(default=datetime.datetime.utcnow)
    # ... 
    #linhas = [] -> 2 Tabelas
    linhas = EmbeddedDocumentListField( Linha )
    meta = { 'db_alias': "orm_ea01"}

"""
f1 = Factura()
f2 = Factura()


Factura
Desc Valor  DATA_FT
"1", 10.00, "1-1-1", Linhas(1,3))

Linhas
# P Q P  IVA
1 1 1 10 23
2 1 2 20 23
3 2 2 30 23
"""