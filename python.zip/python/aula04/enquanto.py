x=10

while x<=100:

    
    if x == 50:
        continue

    print(x)
    x += 10

else:
    print('Fim do While')

   