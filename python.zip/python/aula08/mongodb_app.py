import mongodb_orm

p1 = mongodb_orm.Produto(descricao="Produto01")
p1.save()

l1 = mongodb_orm.Linha( produto=p1, quantidade=10, preco=10, iva=23 )
l2 = mongodb_orm.Linha( produto=p1, quantidade=10, preco=10, iva=23 )

f1 = mongodb_orm.Factura(descricao="Factura N-01", valor=10, linhas=[l1, l2])
f1.save()



print(p1)

