import classes
import unittest


class TestClienteMetodos(unittest.TestCase):

    def test_getChave(self):
        # Prepare
        c1 = classes.Cliente("a", "b", "c", 100, 23 )
        c2 = classes.Cliente("a", "b", "c", 100, 23 )
        c3 = classes.Cliente("a", "b", "c", 100, 23 )
        # Execute
        self.r1 = c1.getChave()
        self.r = classes.Cliente.getIdentity()
        # Assert
        self.assertEqual( self.r , 3 )



if __name__ == "__main__":
    print("Hello")
    
