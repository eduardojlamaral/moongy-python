
conjunto1 = { 1, 4, 5, 6 }
conjunto2 = { 11, 41, 51, 61 }

c3 = conjunto1.union(conjunto2)

print(c3)