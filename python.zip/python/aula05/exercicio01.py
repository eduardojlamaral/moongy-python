import json
import os

#ABC C++ MODULA 

class Pessoa():
    def __init__(self, nome, idade=0 ) -> None:
        self.__nome  = nome
        self.__idade = idade

    # Override __str__ para imprimir uma string no formato json
    def __str__(self) -> str:
        # Pessoa nao e um dict
        data = { 'name': self.__nome, 'age': self.__idade }
        return json.dumps(data)
    
    def setNome(self, nome):
        self.__nome = nome
        
    def setIdade(self, idade):
        self.__idade = idade

class Turma:
    def __init__(self) -> None:
        self.lista = []
        self.lotacao = 5
        self.nome = "pessoa.dat"
        self.carregaFicheiro()


    def carregaFicheiro(self):
        if os.path.exists(self.nome):
            #os.remove("pessoa01.dat")
            f = open(self.nome, "rt")
            for linha in f:
                jlinha = json.loads(linha)        
                self.addPessoa( Pessoa(jlinha["name"], jlinha["age"]), True )
            f.close()
        else:
            f = open(self.nome, "xt")
            f.close()

    # Remover
    # Actualizar

    def addPessoa(self, p:Pessoa, carrega=False ):
        if isinstance( p ,  Pessoa ):
            self.lista.append(p)
            self.lotacao -=1
            f = open(self.nome, "at")
            #f.write(""+p)
            f.close()
        else:
            print("Nao e um objecto da class Pessoa")

    def listaPessoas(self):
        for p in self.lista :
            print(p)



#lista = [ Pessoa("Ed") , Pessoa("Luis", 25) , Pessoa("Jorge"), Pessoa("Bruno") ]
# Max 5 Pessoas