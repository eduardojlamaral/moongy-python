
# Order 
dicionario = { "nome":"Eduardo", "apelido":"Amaral", "idade":200, "morada":["A", "B", "C"] } # NOSQL

print(type(dicionario))

print(dicionario["idade"])

if "idade01" in dicionario:
    print("Existe")
else:
    dicionario["idade01"] = '1-1-1'
    #dicionario.pop("morada")

for a,b in dicionario.items():
    print(a,b)
    print(type(b))
    if isinstance(b, (list,tuple) ):
        print("E uma lista entao bla bla")








