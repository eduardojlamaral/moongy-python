
varLista = ["a", "b", "c", "aa", 14, True]
#varLista.sort()

varLista.append("ultimo")
varLista[3:4]=["outra coisa","ee"]
print(varLista[3:])

l1 = list( (1,2,3) )
print(l1)


            