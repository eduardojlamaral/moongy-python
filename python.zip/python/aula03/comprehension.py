


lista01 = ["a","c","b"]
lista01.sort(reverse=True)

lista02 = [n for n in lista01 if n >= "c"]
lista03 = [n for n in range(12)]
lista04 = [n.upper() for n in lista01]

for item in lista04:
    print(item)

class Aluno():
    x = 10 # Mesma posicao de memoria
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade

    def __str__(self) -> str:
        return f"{self.nome} tem {self.idade}"

    def __lt__(self, proximo):
        return self.idade < proximo.idade

a1 = Aluno("ed", 60)
a2 = Aluno("br", 20)
a3 = Aluno("go", 30)
a4 = Aluno("lu", 10)
a5 = Aluno("an", 40)

lista = [a1, a2, a3, a4, a5]

lista.sort()


for item in lista:
    print(item)


