
class Aluno():
    posicao = 0
    def __init__(self, nome:str , idade:int, indice=10 ):
        Aluno.posicao = indice
        self.nome = nome 
        self.idade = idade

    def __str__(self) -> str:
        return f"{self.nome}:{self.idade}"
    
    def incrementa(self,valor:int):
        Aluno.posicao += valor
    

# f"Luis:12"


a1 = Aluno("Luis",12)
a1.incrementa(valor=1)

a2 = Aluno("Goncalo", 24, 2)
a1.incrementa(valor=4)

#a1.posicao = ???
#a2.posicao = ???

print(a1.posicao)
print(a2.posicao)









