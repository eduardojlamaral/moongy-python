import json

#n = "Luis"
#i = 90
d = '{"nome":"Luis", "idade":0, "morada":[]}'

#print("{" +d.format(n=n, i=i) + "}")~

j = json.loads(d)


print(j["nome"])


dd = {"nome":"Goncalo"}

jj = json.dumps(dd)

print (jj)