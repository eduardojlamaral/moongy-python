
import pymongo
from bson.objectid import ObjectId

client = pymongo.MongoClient("mongodb+srv://dbformacao:akGq6k9yogoggelF@cluster0.nnqg9f9.mongodb.net/?retryWrites=true&w=majority")

print(client.list_database_names())

if "alunos_ea" in client.list_database_names():
    print("DB Ja existe")
else:
    print("DB nao existe")


db_ea = client["alunos_ea"]

tabela = db_ea["disciplinas"]

registo = {"nomeDisciplina":"Python II", "creditos": 6, "curso":"INFORMATICA" , "cursos": ["A","B","C"] }

r1 = tabela.insert_one(registo)
# print(r1)

filtro = {'_id': ObjectId('64b6dcd00ba3ae292419d8c9') }
novo = {"$set": {"curso":"TIC", "versao":200 } }

#query = { "$and": [ dis=2, tit=4 ]}

tabela.update_many( filtro, novo )

ordena = tabela.find().sort("curso", pymongo.ASCENDING )
for x in ordena:
    print(x)

