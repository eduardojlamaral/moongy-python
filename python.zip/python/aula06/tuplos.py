
tuplo = ( 1, 3, 5, 8 , 9, 3, 5)

print(type(tuplo))




print(len(tuplo))