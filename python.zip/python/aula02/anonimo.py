
x = 10
x = 20
y = f(x)

y = lambda n : n*n

z = lambda n1,n2 : n1*n2

#maior = lambda n1,n2 : n1 != n2 and or 

print(y(2))

print(z(2,3))


def tabuada(n):
    return lambda m : m*n


tabuada2 = tabuada(2, 2)

tabuada5 = tabuada(5)

tabuada2(1)
tabuada2(2)

tabuada(2, 1)
tabuada(2, 2)


for zz in range(0, 10):
    print(y(zz))
    print(z(2,zz))


x = 10
y = 20
if x is y:
    print("Hello")
