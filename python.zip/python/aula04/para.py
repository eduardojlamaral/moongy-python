
for x in range(5, 10, 2):
    
    if x == 5:
        continue

    print(x)

else:
    print('Fim do for')