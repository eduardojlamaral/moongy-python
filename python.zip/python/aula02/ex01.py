print('Valor A')
a = input()
print('Valor B')
b = input()

if not a.isnumeric():
    print("valor A invalido")

if not a.isnumeric():
    print("valor B invalido")

print(a+b)

# 1111 1111 = 255 - 123



