import asyncio
import tornado
import mongodb_orm

class ProdutoHandler(tornado.web.RequestHandler):
    def get(self):
        p1 = mongodb_orm.Produto.objects(descricao="Produto01")
        self.write("Hello, world" + str(p1[0]) )

    # POST, DELETE, PUT PATCH


class FacturaHandler(tornado.web.RequestHandler):
    def get(self):
        f1 = mongodb_orm.Factura.objects(descricao="Factura N-01")
        self.write("Hello, world" + str(f1[0]) )

    # POST, DELETE, PUT PATCH


def make_app():
    return tornado.web.Application([
        (r"/produto", ProdutoHandler), (r"/factura", FacturaHandler)
    ])

async def main():
    app = make_app()
    app.listen(8888)
    await asyncio.Event().wait()

if __name__ == "__main__":
    asyncio.run(main())