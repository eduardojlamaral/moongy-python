# Hello

"""
Multi line
1~
2
3
"""

a = 10
b = 10.5
c = 1j  # (j)^2 = -1 Corpo dos Complexos 



d = a+ b
print(d)

# Camel Case
varNomeCompleto = 'Eduardo Amaral' # Serializar JSON
# Pascal Case
VarNomeCompleto = 'Eduardo Amaral' # Serializar JSON
# Snake Case
var_nome_completo = 'Eduardo Amaral' # Serializar JSON

d,f,g = 10,20,30 # Obter info da consola1234

print(g)

z=input()
print(z)

print(type(z))