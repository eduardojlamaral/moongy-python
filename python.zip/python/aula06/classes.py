
class Pessoa:

    identity = 0 # Redis -> MicroServices -

    def __init__(self, nome, apelido ) -> None:
        Pessoa.identity +=1
        self.chave = Pessoa.identity
        self.nome = nome
        self.apelido = apelido

    def getChave(self) -> int:
        return self.chave
    
    def getIdentity():
        return Pessoa.identity


class Cliente(Pessoa):
    def __init__(self, nome, apelido, nif, saldo, iva ) -> None:
        self.nif = nif
        self.saldo = saldo
        self.iva = iva
        super().__init__(nome, apelido)

    def getSaldoSemIvaIncluido(self):
        # Caso 100 com 10% deve ser 90.90 + IVA
        return self.saldo / ( 1 + self.iva/100 )


try: 
    print(0/0)
except NameError:
    print("Nao existe")
except :
    print("Divisao por zero")

finally:
    print("Tudo OK")

"""
c1 = Cliente("a", "b", "c", 100, 23 )
c2 = Cliente("a", "b", "c", 200, 10 )

print(c2.nome)
print( c1.getSaldoIvaIncluido() )
"""

