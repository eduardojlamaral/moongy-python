
numero = 10.56784

texto = "O valor inserido foi {v1} e {v1}"

print(texto.format(v1=1)

# BLAZOR 