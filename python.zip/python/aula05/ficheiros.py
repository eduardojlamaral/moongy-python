import os

# Videos / Musica c:\ddd\s  /home/fdf
# HTTP Servidor -> TEXTO -> JSON 

f = open("pessoa.dat", "rt")

#print(f.readline())
#print(f.readline())

for a in f:
    print(f.readline())

f.close()

if os.path.exists("pessoa01.dat"):
    os.remove("pessoa01.dat")
else:
    f = open("pessoa01.dat", "xt")