
a = "Uma String"
print(len(a))

for z in range(0,10): 
    print(z)

i=0
while i < len(a):
    print(a[i])
    i +=1


if "St" not in a:
    print("Existe")

print(a[4:10])

a.isnumeric()

