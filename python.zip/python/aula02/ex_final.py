# Ler da consola valores adicionar a uma lista se forem numericos
# Deve terminar o pedido caso insira 0 ou atinja o tamanho de 5

def hello(byref, g):

    return g*g

lista = []
while len(lista)<=5:
    print("Qual o Valor "+str(len(lista)+1)+":")
    a = input()
    if a == "0": break
    if a.isnumeric():
        lista.append(a)
    else:
        print("Valor invalido, reppita.")
else:
    print("Leitura Terminada")

lista.sort()


if len(lista)>0:
    print(lista)


class Ghhhh():
    a=0
    def __init__(self, z) -> None:
        zz = z