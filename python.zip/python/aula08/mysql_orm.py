IP = "130.61.246.16"
# root Abcd1234

class Base(DeclarativeBase)

class Produto(Base):
